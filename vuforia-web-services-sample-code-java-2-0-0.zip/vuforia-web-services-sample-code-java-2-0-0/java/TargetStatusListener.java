package com.qualcomm.vuforia.CloudRecognition.samples;

public interface TargetStatusListener {

	public void OnTargetStatusUpdate(TargetState targetState);
}
